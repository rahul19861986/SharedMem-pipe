#include <windows.h>
#include <stdio.h>
#include <time.h>

#define SHARED_MEM_SIZE 1024
#define SHARED_MEM_NAME "Local\\MySharedMemory"

HANDLE hMapFile = NULL;  // Handle to shared memory
char* pBuf = NULL;       // Pointer to shared memory buffer

// Function to initialize IPC (create shared memory)
int initializeIPC()
{
    // Create a file mapping (shared memory)
    hMapFile = CreateFileMapping(
        INVALID_HANDLE_VALUE,    // Use paging file
        NULL,                    // Default security attributes
        PAGE_READWRITE,          // Read/write access
        0,                       // Maximum object size (high-order DWORD)
        SHARED_MEM_SIZE,         // Maximum object size (low-order DWORD)
        SHARED_MEM_NAME);        // Name of the shared memory object

    if (hMapFile == NULL)
    {
        printf("Could not create file mapping object (%lu).\n", GetLastError());
        return 1;
    }

    // Map a view of the file into the address space of the calling process
    pBuf = (char*) MapViewOfFile(
        hMapFile,               // Handle to the map object
        FILE_MAP_ALL_ACCESS,    // Read/write permission
        0,
        0,
        SHARED_MEM_SIZE);

    if (pBuf == NULL)
    {
        printf("Could not map view of file (%lu).\n", GetLastError());
        CloseHandle(hMapFile);
        return 1;
    }

    return 0;  // Success
}

// Function to write messages continuously with a millisecond timestamp
void writeIPC()
{
    SYSTEMTIME st;
    char message[SHARED_MEM_SIZE];
    int counter = 0;

    while (1) // Infinite loop to write continuously
    {
        // Get current system time
        GetSystemTime(&st);

        // Format the message with a millisecond timestamp
        sprintf(message, "Message %d - Time: %02d:%02d:%02d.%03d",
                counter,
                st.wHour,
                st.wMinute,
                st.wSecond,
                st.wMilliseconds);

        // Write the formatted message to shared memory
        memcpy(pBuf, message, strlen(message) + 1);  // +1 for null-termination
        printf("Data written to Pipe: %s\n", message);

        counter++; // Increment the message counter

        // Sleep for 100 milliseconds before writing the next message
        Sleep(1);
    }
}

// Function to close IPC (cleanup)
void closeIPC()
{
    if (pBuf != NULL)
    {
        UnmapViewOfFile(pBuf);  // Unmap the memory
        pBuf = NULL;
    }

    if (hMapFile != NULL)
    {
        CloseHandle(hMapFile);  // Close the file mapping
        hMapFile = NULL;
    }

    printf("IPC closed.\n");
}

int main()
{
    // Step 1: Initialize IPC
    if (initializeIPC() != 0)
    {
        return 1;  // Exit if initialization fails
    }

    // Step 2: Write data to IPC continuously
    writeIPC();

    // This will never be reached, but included for completeness
    closeIPC();

    return 0;
}
