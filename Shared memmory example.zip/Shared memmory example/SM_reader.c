#include <windows.h>
#include <stdio.h>
#include <string.h>  // For strcpy

#define SHARED_MEM_SIZE 1024
#define SHARED_MEM_NAME "Local\\MySharedMemory"

HANDLE hMapFile = NULL;  // Handle to shared memory
char* pBuf = NULL;       // Pointer to shared memory buffer

// Function to initialize IPC (open shared memory)
int initIPC()
{
    // Open an existing file mapping object (shared memory)
    hMapFile = OpenFileMapping(
        FILE_MAP_ALL_ACCESS,   // Read/write access
        FALSE,                 // Do not inherit the name
        SHARED_MEM_NAME);      // Name of the shared memory object

    if (hMapFile == NULL)
    {
        printf("Could not open file mapping object (%lu).\n", GetLastError());
        return 1;
    }

    // Map a view of the file into the address space of the calling process
    pBuf = (char*) MapViewOfFile(
        hMapFile,              // Handle to the map object
        FILE_MAP_ALL_ACCESS,   // Read/write permission
        0,
        0,
        SHARED_MEM_SIZE);

    if (pBuf == NULL)
    {
        printf("Could not map view of file (%lu).\n", GetLastError());
        CloseHandle(hMapFile);
        return 1;
    }

    return 0;  // Success
}

// Function to read data from shared memory continuously
void readIPC()
{
    char lastMessage[SHARED_MEM_SIZE] = { 0 };  // Buffer to store the last read message

    while (1) // Infinite loop to read continuously
    {
        if (strcmp(lastMessage, pBuf) != 0)  // Check if new data is available
        {
            // If the message is different from the last one, print the new message
            printf("Data read from Pipe: %s\n", pBuf);
            strcpy(lastMessage, pBuf);  // Store the last message (use strcpy instead of strcpy_s)
        }

        Sleep(1);  // Sleep for 1 millisecond to avoid high CPU usage
    }
}

// Function to close IPC (cleanup)
void closeIPC()
{
    if (pBuf != NULL)
    {
        UnmapViewOfFile(pBuf);  // Unmap the memory
        pBuf = NULL;
    }

    if (hMapFile != NULL)
    {
        CloseHandle(hMapFile);  // Close the file mapping
        hMapFile = NULL;
    }

    printf("IPC closed.\n");
}

int main()
{
    // Step 1: Initialize IPC
    if (initIPC() != 0)
    {
        return 1;  // Exit if initialization fails
    }

    // Step 2: Continuously read data from IPC
    readIPC();

    // This will never be reached, but included for completeness
    closeIPC();

    return 0;
}
